#ifndef TYPES_H
#define TYPES_H

#define CHAR_SIZE 256
#define LARGE_CHAR_SIZE 1024
#define DATE_CHAR_SIZE 20
#define API_TOKEN_SIZE 65

#endif // TYPES_H